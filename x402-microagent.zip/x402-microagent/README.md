# x402 Microagent

A read-only starter for discovering very cheap x402-compatible HTTP resources on Solana.

## Important

This version **does not make payments**. It only discovers and ranks candidate resources.

Finding a $0.01 endpoint is not the same as finding free money. The later economic agent must verify that an action can create revenue greater than its payment, fees, and risk.

## Security

- Never put a Solana seed phrase or private key in this repository.
- `PUBLIC_WALLET` is only for a public destination/address if needed later.
- Autonomous payments require a separate signing mechanism with strict spending limits.

## Run locally

```bash
npm install
npm run scan
```

## GitHub Actions

The workflow runs every 30 minutes and can also be started manually.

## Next stage

1. Discover x402 resources.
2. Identify opportunities where expected value exceeds cost.
3. Add strict allowlists and spending caps.
4. Only then consider a dedicated signer for payments.
