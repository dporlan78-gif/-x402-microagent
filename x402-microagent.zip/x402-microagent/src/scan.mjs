const BASE = process.env.BAZAAR_URL || "https://api.x402.org";
const network = process.env.SOLANA_NETWORK || "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp";
const maxUsd = Number(process.env.MAX_USD || "0.01");
const limit = Math.min(Number(process.env.LIMIT || "100"), 100);

const url = new URL("/discovery/resources", BASE);
url.searchParams.set("type", "http");
url.searchParams.set("network", network);
url.searchParams.set("limit", String(limit));

const res = await fetch(url);
if (!res.ok) throw new Error(`Discovery request failed: ${res.status} ${res.statusText}`);

const data = await res.json();
const items = Array.isArray(data?.items) ? data.items : [];

const keywords = [
  "reward", "bounty", "cashback", "rebate", "payout",
  "earn", "arbitrage", "market", "price", "lead"
];

function usdFromAccept(accept) {
  const amount = String(accept?.amount ?? "");
  const asset = String(accept?.asset ?? "").toLowerCase();
  if (!amount || !asset.includes("usdc")) return null;
  const n = Number(amount);
  if (!Number.isFinite(n)) return null;
  return n / 1_000_000;
}

const candidates = [];
for (const item of items) {
  for (const accept of (item.accepts || [])) {
    if (accept.network !== network) continue;
    const priceUsd = usdFromAccept(accept);
    if (priceUsd === null || priceUsd > maxUsd) continue;

    const text = `${item.resource || ""} ${item.description || ""}`.toLowerCase();
    let score = 0;
    if (String(accept.scheme || "").toLowerCase() === "exact") score += 2;
    if (String(accept.asset || "").toLowerCase().includes("usdc")) score += 2;
    for (const k of keywords) if (text.includes(k)) score += 1;

    candidates.push({
      resource: item.resource,
      description: item.description || "",
      scheme: accept.scheme,
      network: accept.network,
      asset: accept.asset,
      payTo: accept.payTo,
      priceUsd,
      score
    });
  }
}

candidates.sort((a, b) => b.score - a.score || a.priceUsd - b.priceUsd);

console.log(JSON.stringify({
  mode: "discovery-only",
  generatedAt: new Date().toISOString(),
  scanned: items.length,
  candidates: candidates.slice(0, 50)
}, null, 2));
